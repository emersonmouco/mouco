﻿namespace FatecLibrary.Web.Roles
{
    public static class Role
    {
        public const string Admin = "Admin";
        public const string Client = "Client";
    }
}
